[本体URL]
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=453&event=146

[ズレ抜け]
同梱_hinagata.hinagataをベースに作成
以下の小節に曲改変有り

#025 (フィルインの改変、音数を減らした)
#033,#058 (シンバルの追加)

[NOTES / TOTAL]
1931 notes / 500 (0.259)
3131 notes / 620 (0.198)

[雑記]
・縹渺リフレイン
ひょうびょう
歌LN成分が足りなかったので自分が満足するために後から作った
いつもの☆11、表で言うと個人差あるsl0 (slかsoの判断は他の人に任せます)

・Seize the Day
歌微縦
横に広くしたり裏から入ったり長い音に当てたり、曲に合うよう色々なパターンを織り交ぜている
歌のキー音が切られており普通に配置しているのでミスると音痴になるのだけ注意
st3?

[譜面リファレンス]
・縹渺リフレイン
群青ミラージュ ～虹の先へ～ / 天束 feat. はらもりよしな, Lalot.（速度変化の参考）

・Seize the Day
Tone deafness -Xe- / SOMON, LindBlum
冬霞 [寒暁] / 優木沙雪 feat.可不, potechang