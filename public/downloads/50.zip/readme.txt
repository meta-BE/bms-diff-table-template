[本体URL]
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=6&event=148

[ズレ抜け]
同梱_nakaiankow_eeeeee.bms.emptyをベースに作成、ズレ抜けなし

[NOTES / TOTAL]
2529 notes / 499 (0.197)

[雑記]
拾ってる音がわかる配置で詰め込んだ古き良き発狂スタイル
速い微縦とかぐちゃぐちゃした同時
当たり外れが激しいというよりは特定レーンにずっと降ってくるので判別が必要かも
st3?