[本体URL]
https://venue.bmssearch.net/bmstukuru2026/93

[ズレ抜け]
同梱 _00_Blank.bmx をベースに作成、以下の意図的な変更あり

#097-#100：シンバル追加
#111：24分の配置ミスと思われるものを修正

[NOTES / TOTAL]
3330 notes / 600 (0.180)

[雑記]
楽しい二重乱打、最終的に体力ゲー
★12くらいの気持ちだけど難所が強め


[譜面リファレンス]
black opal [Pentagon] / TAK vs General / Jeff obj.hex
Carmina / CANVAS feat. Quimär