[本体URL]
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=18&event=148

[ズレ抜け]
同梱_.emptyをベースに作成、以下の追加あり
#058 16	(1 / 4)	#WAV42 (crash.wav)
#099 16	(1 / 4)	#WAV42 (crash.wav)

[NOTES / TOTAL]
2768 notes / 620 (0.224)

[雑記]
いろいろな高速と発狂する譜面
と思ったら普通に中盤が山場になった
st3-4?

[譜面リファレンス]
Schwerkraft [すごそうな譜面] / ROKINA, 仙人掌の人